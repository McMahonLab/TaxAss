FreshTrain version 18Aug2016:
edited by Robin to fix "typos" (note: arb file may or may not be updated accordingly)

deleted:
Gm9Prot2
Gm9Pro24
Gm9Pro25
UniBac24
Gm9Prot5

changed to be o_undefinedAlpha:
McDucnp2
CanPhyco

changed to be o__Acidimicrobiales and c__Acidimicrobiia
AcmBacte

Further changes in FreshTrain version 25Jan2018
edited by Josh to fix odd classifications (note: arb file may or may
not be updated accordingly)

classification changed:
Bctrm480       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan20       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan22       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LiUU2020       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;

Further changes in FreshTrain version 25Jan2018NoBadLineages
edited by Josh to remove all strains that don't belong to a
freshwater-specific lineage as defined in Newton 2011


Further changes in FreshTrain version 25Jan2018NoBadLineagesSILVAv132
Update taxonomic structure so it agrees with SILVA v132. Changes are:
Lineage		 Old Classification		New Classification
bacI		     	c__[Saprospirae]		c__Sphingobacteriia(100)
bacIV		c__[Saprospirae]		c__Sphingobacteriia(100)
LD19		c__[Methylacidiphilae]	c__Verrucomicrobia_Incertae_Sedis(100)
verI-A		c__[Spartobacteria]		c__Spartobacteria(100)
verI-B		c__[Spartobacteria]		c__Spartobacteria(100)
		
acI			o__Actinomycetales	o__Frankiales(100)
acIII			o__Actinomycetales	o__Micrococcales(100)
acSTL		o__Actinomycetales	o__Frankiales(97)
acTH1		o__Actinomycetales	o__Frankiales(100)
acTH2		o__Actinomycetales	o__Corynebacteriales(100)
alfV			o__Rickettsiales		o__SAR11_clade(100)
bacI			o__[Saprospirales]		o__Sphingobacteriales(100)
bacIV		o__[Saprospirales]		o__Sphingobacteriales(100)
LD19		o__Methylacidiphilales	o__Unknown_Order(100)
Luna1		o__Actinomycetales	o__Micrococcales(100)
Luna3		o__Actinomycetales	o__Micrococcales(100)
verI-A		o__[Chthoniobacterales]	o__Chthoniobacterales(100)
verI-B		o__[Chthoniobacterales]	o__Chthoniobacterales(100)
