FreshTrain version 18Aug2016:
edited by Robin to fix "typos" (note: arb file may or may not be updated accordingly)

deleted:
Gm9Prot2
Gm9Pro24
Gm9Pro25
UniBac24
Gm9Prot5

changed to be o_undefinedAlpha:
McDucnp2
CanPhyco

changed to be o__Acidimicrobiales and c__Acidimicrobiia
AcmBacte

Further changes in FreshTrain version 25Jan2018
edited by Josh to fix odd classifications (note: arb file may or may
not be updated accordingly)

classification changed:
Bctrm480       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan20       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan22       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LiUU2020       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;

Further changes in FreshTrain version 25Jan2018NoBadLineages
edited by Josh to remove all strains that don't belong to a
freshwater-specific lineage as defined in Newton 2011


Further changes in FreshTrain version 25Jan2018NoBadLineagesSILVAv132
Update taxonomic structure so it agrees with SILVA v132. Changes are:
Lineage		 	      	 	     	   	Old Classification		New Classification
bacI, bac IV						c__[Saprospirae]		c__Bacteroidia(100)
bacI, bac IV						o__[Saprospirales]		o__Chitinophagales(100)
bacII, bacV						c__Flavobacteriia		c__Bacteroidia(100)
bacIII							c__Cytophagia			c__Bacteroidia(100)
bacVI							c__Sphingobacteriia	c__Bacteroidia(100)
betI, betII, betIII, betIV, betV, betVII		c__Betaproteobacteria	c__Gammaproteobacteria(100)
betI, betII, betIII, bet VII	  			o__Burkholderiales		o__Betaproteobacteriales(100)
betIV							o__Methylophilales		o__Betaproteobacteriales(100)
betV								o__undefined			o__Betaproteobacteriales(100)
LD19							c__[Methylacidiphilae]	c__Verrucomicrobiae(100)
verI-A, verI-B						c__[Spartobacteria]		c__Verrucomicrobiae(100)
verI-A, verI-B						o__[Chthoniobacterales]	o__Chthoniobacterales(100)
acI, acSTL, acTH1					o__Actinomycetales	o__Frankiales(100)
acIII	    							o__Actinomycetales	o__Micrococcales(100)
acIV								o__Acidimicrobiales	o__Microtrichales(100)
acTH2							o__Actinomycetales	o__Corynebacteriales(100)
acV								o__Acidimicrobiales	o__uncultured(100)
alfV								o__Rickettsiales		o__SAR11_clade(100)
alfVIII							o__Rhodospirillales		o__Acetobacterales(100)
Luna1, Luna3						o__Actinomycetales	o__Micrococcales(100)
