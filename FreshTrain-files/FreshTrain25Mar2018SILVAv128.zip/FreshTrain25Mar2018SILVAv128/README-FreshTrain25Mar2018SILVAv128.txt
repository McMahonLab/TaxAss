Changes to FreshTrain after ARB export:

------------------------------------------------------------------------------------------
FreshTrain version 18Aug2016:
edited by Robin to fix "typos" (note: arb file may or may not be updated accordingly)

deleted:
Gm9Prot2
Gm9Pro24
Gm9Pro25
UniBac24
Gm9Prot5

changed to be o_undefinedAlpha:
McDucnp2
CanPhyco

changed to be o__Acidimicrobiales and c__Acidimicrobiia
AcmBacte

------------------------------------------------------------------------------------------
FreshTrain version 25Jan2018 Greengenes13_5
(edits to version 18Aug2016)

edited by Josh to fix odd classifications (note: arb file may or may not be updated accordingly)

classification changed:
Bctrm480       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan20       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan22       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LiUU2020       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;

edited by Josh to remove all strains that don't belong to a freshwater-specific lineage as defined in Newton 2011
using removeBadLineage.py

------------------------------------------------------------------------------------------
FreshTrain version 25Mar2018 SILVAv128
(edits to version 25Jan2018Greengenes13_5)

Using Josh's script convertFreshTrainToSilvaV128.py 
update phylum to order taxonomic nomenclature so it agrees with SILVA v128

pwd is FreshTrain-files
$ python ../arb-scripts/convertFreshTrainToSilvaV128.py FreshTrain25Jan2018Greengenes13_5/FreshTrain25Jan2018Greengenes13_5.taxonomy FreshTrain25Mar2018SILVAv128/FreshTrain25Mar2018SILVAv128_temp.taxonomy

This adjusted the class names of the following to be:

bacI	c__Sphingobacteriia
bacIV	c__Sphingobacteriia
LD19	c__Verrucomicrobia_Incertae_Sedis
verI-A	c__Spartobacteria
verI-B	c__Spartobacteria

This adjusted the order names of the following to be:

acI		o__Frankiales
acIII	o__Micrococcales
acSTL	o__Frankiales
acTH1	o__Frankiales
acTH2	o__Corynebacteriales
alfV	o__SAR11_clade
bacI	o__Sphingobacteriales
bacIV	o__Sphingobacteriales
LD19	o__Unknown_Order
Luna1	o__Micrococcales
Luna3	o__Micrococcales
verI-A	o__Chthoniobacterales
verI-B	o__Chthoniobacterales


Also using Robin's script remove_gg_taxa_level_prefixes.sh
all of the k__ p__ c__ o__ prefixes were removed so that names match silva, which doesn't have those.

pwd is FreshTrain-files
$ ../arb-scripts/remove_gg_taxa_level_prefixes.sh FreshTrain25Mar2018SILVAv128/FreshTrain25Mar2018SILVAv128_temp.taxonomy FreshTrain25Mar2018SILVAv128/FreshTrain25Mar2018SILVAv128.taxonomy
$ rm FreshTrain25Mar2018SILVAv128/FreshTrain25Mar2018SILVAv128_temp.taxonomy

(No changes made to fasta file, simply renamed the 25Jan2018Greengenes13_5 one)

------------------------------------------------------------------------------------------
