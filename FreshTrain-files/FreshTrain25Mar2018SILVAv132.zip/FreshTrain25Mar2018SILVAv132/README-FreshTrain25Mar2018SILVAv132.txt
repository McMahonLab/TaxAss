Changes to FreshTrain after ARB export:

------------------------------------------------------------------------------------------
FreshTrain version 18Aug2016:
edited by Robin to fix "typos" (note: arb file may or may not be updated accordingly)

deleted:
Gm9Prot2
Gm9Pro24
Gm9Pro25
UniBac24
Gm9Prot5

changed to be o_undefinedAlpha:
McDucnp2
CanPhyco

changed to be o__Acidimicrobiales and c__Acidimicrobiia
AcmBacte

------------------------------------------------------------------------------------------
FreshTrain version 25Jan2018 Greengenes13_5
(edits to version 18Aug2016)

edited by Josh to fix odd classifications (note: arb file may or may not be updated accordingly)

classification changed:
Bctrm480       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan20       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan22       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LiUU2020       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;

edited by Josh to remove all strains that don't belong to a freshwater-specific lineage as defined in Newton 2011
using removeBadLineage.py

------------------------------------------------------------------------------------------
FreshTrain version 25Mar2018 SILVAv132
(edits to version 25Jan2018Greengenes13_5)

Using Josh's script convertFreshTrainToSilvaV132.py 
update phylum to order taxonomic nomenclature so it agrees with SILVA v132

pwd is FreshTrain-files
$ python ../arb-scripts/convertFreshTrainToSilvaV132.py FreshTrain25Jan2018Greengenes13_5/FreshTrain25Jan2018Greengenes13_5.taxonomy FreshTrain25Mar2018SILVAv132/FreshTrain25Jan2018SILVAv132.taxonomy

This adjusted the following to have these class names:

bacI	c__Bacteroidia
bacII	c__Bacteroidia
bacIII	c__Bacteroidia
bacIV	c__Bacteroidia
bacV	c__Bacteroidia
bacVI	c__Bacteroidia
betI	c__Gammaproteobacteria
betII	c__Gammaproteobacteria
betIII	c__Gammaproteobacteria
betIV	c__Gammaproteobacteria
betV	c__Gammaproteobacteria
betVII	c__Gammaproteobacteria
LD19	c__Verrucomicrobiae
verI-A	c__Verrucomicrobiae
verI-B	c__Verrucomicrobiae

This adjusted the following to have these order names:

acI		o__Frankiales
acIII	o__Micrococcales
acIV	o__Microtrichales
acSTL	o__Frankiales
acTH1	o__Frankiales
acTH2	o__Corynebacteriales
acV		o__uncultured
alfV	o__SAR11_clade
alfVIII	o__Acetobacterales
bacI	o__Chitinophagales
bacIV	o__Chitinophagales
betI	o__Betaproteobacteriales
betII	o__Betaproteobacteriales
betIII	o__Betaproteobacteriales
betIV	o__Betaproteobacteriales
betV	o__Betaproteobacteriales
betVII	o__Betaproteobacteriales
Luna1	o__Micrococcales
Luna3	o__Micrococcales
verI-A	o__Chthoniobacterales
verI-B	o__Chthoniobacterales


Also using Robin's script remove_gg_taxa_level_prefixes.sh
all of the k__ p__ c__ o__ prefixes were removed so that names match silva, which doesn't have those.

pwd is FreshTrain-files
$ ../arb-scripts/remove_gg_taxa_level_prefixes.sh FreshTrain25Mar2018SILVAv132/FreshTrain25Jan2018SILVAv132_temp.taxonomy FreshTrain25Mar2018SILVAv132/FreshTrain25Jan2018SILVAv132.taxonomy
$ rm FreshTrain25Mar2018SILVAv132/FreshTrain25Jan2018SILVAv132_temp.taxonomy

(No changes made to fasta file, simply renamed the 25Jan2018Greengenes13_5 one)

------------------------------------------------------------------------------------------
