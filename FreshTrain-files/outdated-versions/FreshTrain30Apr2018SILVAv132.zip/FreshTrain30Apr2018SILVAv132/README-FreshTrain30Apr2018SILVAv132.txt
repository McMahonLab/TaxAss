Changes to FreshTrain after ARB export:

------------------------------------------------------------------------------------------
FreshTrain version 18Aug2016:
edited by Robin to fix "typos" (note: arb file may or may not be updated accordingly)

deleted:
Gm9Prot2
Gm9Pro24
Gm9Pro25
UniBac24
Gm9Prot5

changed to be o_undefinedAlpha:
McDucnp2
CanPhyco

changed to be o__Acidimicrobiales and c__Acidimicrobiia
AcmBacte

------------------------------------------------------------------------------------------
FreshTrain version 25Jan2018 Greengenes13_5
(edits to version 18Aug2016)

edited by Josh to fix odd classifications (note: arb file may or may not be updated accordingly)

classification changed:
Bctrm480       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan20       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LakTan22       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;
LiUU2020       k__Bacteria;p__Proteobacteria;c__Betaproteobacteria;o__Burkholderiales;betVI;unclassified;unclassified;


edited by Josh to remove all strains that don't belong to a freshwater-specific lineage as defined in Newton 2011 using

removeBadLineage.py

------------------------------------------------------------------------------------------
FreshTrain version 30Apr2018 SILVA v132
(edits to version 25Jan2018)

________________
Manually deleted references from taxonomy and fasta files that ended up with non-monophyletic structure:

AbmAct53
LaeeEE00p1
PavinActino1
(because they were order PeM15 and other 8 acSTL lineages were order Frankiales)

________________
Adjusted coarse-level nomenclature using:

convertFreshTrainToSilvaV132.py

Which changed: 
lineage		old order				new order
acI			Actinomycetales			Frankiales
acIII		Actinomycetales			Micrococcales
acIV		Acidimicrobiales		Microtrichales
acSTL		Actinomycetales			Frankiales
acSTL		Actinomycetales			PeM15
acTH1		Actinomycetales			Frankiales
acTH2		Actinomycetales			Corynebacteriales
alfV		Rickettsiales			SAR11_clade
alfVIII		Rhodospirillales		Acetobacterales
bacI		[Saprospirales]			Chitinophagales
bacIV		[Saprospirales]			Chitinophagales
betI		Burkholderiales			Betaproteobacteriales
betII		Burkholderiales			Betaproteobacteriales
betIII		Burkholderiales			Betaproteobacteriales
betIV		Methylophilales			Betaproteobacteriales
betV		undefined				Betaproteobacteriales
betVII		Burkholderiales			Betaproteobacteriales
Luna1		Actinomycetales			Micrococcales
Luna3		Actinomycetales			Micrococcales
verI-A		[Chthoniobacterales]	Chthoniobacterales
verI-B		[Chthoniobacterales]	Chthoniobacterales
		
		
lineage		old class				new class
bacI		[Saprospirae]			Bacteroidia
bacII		Flavobacteriia			Bacteroidia
bacIII		Cytophagia				Bacteroidia
bacIV		[Saprospirae]			Bacteroidia
bacV		Flavobacteriia			Bacteroidia
bacVI		Sphingobacteriia		Bacteroidia
betI		Betaproteobacteria		Gammaproteobacteria
betII		Betaproteobacteria		Gammaproteobacteria
betIII		Betaproteobacteria		Gammaproteobacteria
betIV		Betaproteobacteria		Gammaproteobacteria
betV		Betaproteobacteria		Gammaproteobacteria
betVII		Betaproteobacteria		Gammaproteobacteria
LD19		[Methylacidiphilae]		Verrucomicrobiae
verI-A		[Spartobacteria]		Verrucomicrobiae
verI-B		[Spartobacteria]		Verrucomicrobiae

________________
Removed the k__ p__ c__ o__ prefixes using:

remove_gg_taxa_level_prefixes.sh

------------------------------------------------------------------------------------------
