FreshTrain version 18Aug2016:
edited by Robin to fix "typos" (note: arb file may or may not be updated accordingly)

deleted:
Gm9Prot2
Gm9Pro24
Gm9Pro25
UniBac24
Gm9Prot5

changed to be o_undefinedAlpha:
McDucnp2
CanPhyco

changed to be o__Acidimicrobiales and c__Acidimicrobiia
AcmBacte