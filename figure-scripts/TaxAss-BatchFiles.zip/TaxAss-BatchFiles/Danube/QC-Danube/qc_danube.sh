#!/bin/bash

# download and QC the danube river fastq reads for the TaxAss manuscript
# This is from SRP045083 

# trim reference alignment (Pat Schloss's SILVA SEED) to the danube primer region: forward CCTACGGGNGGCWGCAG	reverse GACTACHVGGGTATCTAATCC
# these coordinates account for a bug in the current version of mother v.1.39.5 that trims an extra bp off the forward end
# the danube sequence reads incorrectly include the primer/barcodes as entered in SRA, so trim to remove all primers here
cp ../../ReferenceDatabases/silva.seed_v128.align silva.seed_v128.align
mothur "#pcr.seqs(fasta=silva.seed_v128.align, start=6426, end=23440, keepdots=F, nomatch=reject, pdiffs=0, rdiffs=0)" &&

# download the fastq files from NCBI SRA, search SRA number SRP045083 in the search bar
# at top right corner of page click send to -> file -> accession list save with default name: SraAccList.txt
while read "SRR"; do
   echo "$SRR"
   fastq-dump --split-files --skip-technical --outdir ./ "$SRR"
done < SraAccList.txt

# convert paired fastq into fasta
mothur "#make.file(inputdir=./, type=fastq, prefix=danube, numcols=3)" &&
mothur "#make.contigs(file=danube.files, processors=2, pdiffs=0, bdiffs=0, tdiffs=0, checkorient=f, align=needleman, match=1, mismatch=-1, gapopen=-2, gapextend=-1, insert=20, deltaq=6, trimoverlap=F, rename=F)" 

# use mothur to QC, align, and chimera-check the fasta file
mothur "#screen.seqs(fasta=danube.trim.contigs.fasta, group=danube.contigs.groups, maxambig=0, maxhomop=9, processors=2)"
mothur "#unique.seqs(fasta=danube.trim.contigs.good.fasta)"
mothur "#count.seqs(name=danube.trim.contigs.good.names, group=danube.contigs.good.groups)"
mothur "#align.seqs(fasta=danube.trim.contigs.good.unique.fasta, reference=silva.seed_v128.pcr.align, flip=t, processors=2)"
# start=2 and end=17014 chosen based on alignment of majority of sequences
mothur "#screen.seqs(fasta=danube.trim.contigs.good.unique.align, count=danube.trim.contigs.good.count_table, start=2, end=17014, processors=2)"
mothur "#filter.seqs(fasta=danube.trim.contigs.good.unique.good.align, vertical=T, trump=., processors=2)" 
mothur "#unique.seqs(fasta=danube.trim.contigs.good.unique.good.filter.fasta, count=danube.trim.contigs.good.good.count_table)"
mothur "#chimera.vsearch(fasta=danube.trim.contigs.good.unique.good.filter.unique.fasta, count=danube.trim.contigs.good.unique.good.filter.count_table, dereplicate=t, processors=2, abskew=1.9, minh=.3, xn=8, mindiv=.5, mindiffs=3, dn=1.4)"
mothur "#remove.seqs(fasta=danube.trim.contigs.good.unique.good.filter.unique.fasta, accnos=danube.trim.contigs.good.unique.good.filter.unique.denovo.vsearch.accnos)"
cp danube.trim.contigs.good.unique.good.filter.unique.pick.fasta temp.fasta
cp danube.trim.contigs.good.unique.good.filter.denovo.vsearch.pick.count_table temp.count_table
rm mothur.*.logfile 
rm danube.*
rm SRR*
rm silva.*
mv temp.fasta danube.fasta
mv temp.count_table danube.count_table

exit