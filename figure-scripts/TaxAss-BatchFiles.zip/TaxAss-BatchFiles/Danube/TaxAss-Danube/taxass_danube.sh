#!/bin/bash

# TaxAss Danube!

# add ref files:
cp ../../ReferenceDatabases/gg_13_5.fasta general.fasta
cp ../../ReferenceDatabases/gg_13_5_taxonomy.txt gg_13_5_taxonomy.txt
cp ../../ReferenceDatabases/FreshTrain18Aug2016.fasta custom.fasta
cp ../../ReferenceDatabases/FreshTrain18Aug2016.taxonomy custom.taxonomy
# add scripts
cp ../../tax-scripts/* ./
# add QC'ed data
cp ../QC-Danube/danube.fasta ./
cp ../QC-Danube/danube.count_table ./

# reformatting (step 0)
./reformat_greengenes.sh gg_13_5_taxonomy.txt
sed 's/-//g' <../QC-Danube/danube.fasta >otus.fasta
rm danube.fasta
Rscript reformat_mothur_OTU_tables.R danube.count_table count_table otus.abund
rm danube.count_table

# compare results with different percent identity cutoffs.
# note: have to change percent identity range and bootstrap cutoff choices at the top of 
# the RunSteps batch scripts.
# note: used wang classifier bootstrap cutoff of 80% confidence for both classifications
./RunSteps_1-14.sh > termout_temp.txt

# choose percent identity cutoff of 98% by looking at plots!
./RunStep_15.sh >> termout_temp.txt

# save the terminal output after deleting stupid mothur lines (to check for error messages)
./deletemothurbarf.sh termout_temp.txt terminal_output_taxass.txt
rm termout_temp.txt

# clean up directory
./RunStep_16.sh


exit