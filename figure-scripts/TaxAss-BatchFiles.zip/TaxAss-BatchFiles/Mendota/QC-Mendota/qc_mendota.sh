#!/bin/bash

# Batch file to process the Mendota reads for the TaxAss Manuscript
# RRR 6-20-17

# get ballpark timing estimate
printf "starting Mendota qc\n" >> timing.txt
date >> timing.txt

# trim reference alignment (Pat Schloss's SILVA SEED) to Mendota's V4 primer region: forward GTGCCAGCMGCCGCGGTAA reverse GGACTACHVGGGTWTCTAAT
# this includes the primer b/c a bug in the current version of mother v.1.39.5 trims as extra bp off the forward end
# the ERR mendota sequences already have the primer trimmed off of them
cp ../../ReferenceDatabases/silva.seed_v128.align silva.seed_v128.align
mothur "#pcr.seqs(fasta=silva.seed_v128.align, start=11895, end=25318, keepdots=F, nomatch=reject, pdiffs=0, rdiffs=0)" &&
rm mothur.*.logfile 

# download the fastq files from NCBI SRA, search SRA number ERP016591 in the search bar
# at top right corner of page click send to -> file -> accession list save with default name: SraAccList.txt
while read "SRR"; do
   echo "$SRR"
   fastq-dump --split-files --skip-technical --outdir ./ "$SRR"
done < SraAccList.txt

# use vsearch to QC the single-read illumina fastq data and convert to mothur-friendly fasta (mothur can't handle this old format well)
fastqfiles=`ls *.fastq`
fastqnames=`echo $fastqfiles | sed 's/\.fastq//g'`
fastastring=""
groupstring=""
for SRR in $fastqnames
do
   echo $SRR
   vsearch --fastq_filter $SRR.fastq --fastq_maxee .5 --fastq_trunclen 100 --fastaout $SRR.trim.fasta
   fastastring+="-$SRR.trim.fasta"
   groupstring+="-$SRR"
done
mothurfastastring=`echo $fastastring | sed 's/-//'`
mothurgroupstring=`echo $groupstring | sed 's/-//'`
mothur "#merge.files(input=$mothurfastastring, output=mendota.trim.contigs.fasta)" &&
mothur "#make.group(fasta=$mothurfastastring, groups=$mothurgroupstring)" &&
mv *.groups mendota.contigs.groups
rm mothur.*.logfile 

# use mothur to QC, align, and chimera-check the fasta file
mothur "#screen.seqs(fasta=mendota.trim.contigs.fasta, group=mendota.contigs.groups, maxambig=0, maxhomop=9)"
mothur "#unique.seqs(fasta=mendota.trim.contigs.good.fasta)"
mothur "#count.seqs(name=mendota.trim.contigs.good.names, group=mendota.contigs.good.groups)"
mothur "#align.seqs(fasta=mendota.trim.contigs.good.unique.fasta, reference=silva.seed_v128.pcr.align, flip=t)"
# start=1967 and end=4412 chosen based on alignment of majority of sequences
mothur "#screen.seqs(fasta=mendota.trim.contigs.good.unique.align, count=mendota.trim.contigs.good.count_table, start=1967, end=4412)"
mothur "#filter.seqs(fasta=mendota.trim.contigs.good.unique.good.align, vertical=T, trump=.)" 
mothur "#unique.seqs(fasta=mendota.trim.contigs.good.unique.good.filter.fasta, count=mendota.trim.contigs.good.good.count_table)"
mothur "#chimera.vsearch(fasta=mendota.trim.contigs.good.unique.good.filter.unique.fasta, count=mendota.trim.contigs.good.unique.good.filter.count_table, dereplicate=t, processors=1, abskew=1.9, minh=.3, xn=8, mindiv=.5, mindiffs=3, dn=1.4)"
mothur "#remove.seqs(fasta=mendota.trim.contigs.good.unique.good.filter.unique.fasta, accnos=mendota.trim.contigs.good.unique.good.filter.unique.denovo.vsearch.accnos)"
cp mendota.trim.contigs.good.unique.good.filter.unique.pick.fasta temp.fasta
cp mendota.trim.contigs.good.unique.good.filter.denovo.vsearch.pick.count_table temp.count_table
rm mothur.*.logfile 
rm mendota.*
rm ERR*
rm silva.*
mv temp.fasta mendota.fasta
mv temp.count_table mendota.count_table

printf "ending mendota qc\n" >> timing.txt
date >> timing.txt


