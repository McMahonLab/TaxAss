#!/bin/bash

# TaxAss Mendota without comparisons and checks (as quick as possible)
# choose 98% percent identity cutoff and bootstrap confidences of 80%

# add ref files:
cp ../../ReferenceDatabases/gg_13_5.fasta general.fasta
cp ../../ReferenceDatabases/gg_13_5_taxonomy.txt gg_13_5_taxonomy.txt
cp ../../ReferenceDatabases/FreshTrain18Aug2016.fasta custom.fasta
cp ../../ReferenceDatabases/FreshTrain18Aug2016.taxonomy custom.taxonomy
# add scripts
cp ../../tax-scripts/* ./
# add QC'ed data
cp ../QC-Mendota/mendota.fasta ./
cp ../QC-Mendota/mendota.count_table ./

# reformatting (step 0)
./reformat_greengenes.sh gg_13_5_taxonomy.txt
sed 's/-//g' <../QC-Mendota/mendota.fasta >otus.fasta
rm mendota.fasta
Rscript reformat_mothur_OTU_tables.R mendota.count_table count_table otus.abund
rm mendota.count_table

# When I say TAX, you say ASS! TAX ...
./RunSteps_quickie.sh > termout_quickie.txt
./deletemothurbarf.sh termout_quickie.txt > termout_quickie_temp.txt
mv termout_quickie_temp.txt termout_quickie.txt

# clean up directory
./RunStep_16.sh


exit