#!/bin/bash

# download and QC the lake michigan fastq reads for the TaxAss manuscript
# This is from SRP056973, which also includes urban stormwater and urban river samples.
# To download the accession numbers used, select all 14 results with "Lake Michigan" in the name

# get ballpark timing estimate
printf "starting michigan qc\n" >> timing.txt
date >> timing.txt

# trim reference alignment (Pat Schloss's SILVA SEED) to the michigan v6 primer region: forward CNACGCGAAGAACCTTANC   reverse CGACRRCCATGCANCACCT
# these coordinates account for a bug in the current version of mother v.1.39.5 that trims an extra bp off the forward end
# the michigan sequence reads incorrectly include the primer/barcodes as entered in SRA, so trim to remove all primers here
cp ../../ReferenceDatabases/silva.seed_v128.align silva.seed_v128.align
mothur "#pcr.seqs(fasta=silva.seed_v128.align, start=31187, end=33183, keepdots=F, nomatch=reject, pdiffs=0, rdiffs=0)" &&

# download the fastq files from NCBI SRA, search SRA number SRP056973 in the search bar
# at top right corner of page click send to -> file -> accession list save with default name: SraAccList.txt
while read "SRR"; do
   echo "$SRR"
   fastq-dump --split-files --skip-technical --outdir ./ "$SRR"
done < SraAccList.txt

# convert paired fastq into fasta
mothur "#make.file(inputdir=./, type=fastq, prefix=michigan, numcols=3)" &&
mothur "#make.contigs(file=michigan.files, processors=2, pdiffs=0, bdiffs=0, tdiffs=0, checkorient=f, align=needleman, match=1, mismatch=-1, gapopen=-2, gapextend=-1, insert=20, deltaq=6, trimoverlap=F, rename=F)" 

# use mothur to QC, align, and chimera-check the fasta file
mothur "#screen.seqs(fasta=michigan.trim.contigs.fasta, group=michigan.contigs.groups, maxambig=0, maxhomop=9, processors=2)"
mothur "#unique.seqs(fasta=michigan.trim.contigs.good.fasta)"
mothur "#count.seqs(name=michigan.trim.contigs.good.names, group=michigan.contigs.good.groups)"
mothur "#align.seqs(fasta=michigan.trim.contigs.good.unique.fasta, reference=silva.seed_v128.pcr.align, flip=t, processors=2)"
# start=2 and end=1996 chosen based on alignment of majority of sequences
mothur "#screen.seqs(fasta=michigan.trim.contigs.good.unique.align, count=michigan.trim.contigs.good.count_table, start=2, end=1996, processors=2)"
mothur "#filter.seqs(fasta=michigan.trim.contigs.good.unique.good.align, vertical=T, trump=., processors=2)" 
mothur "#unique.seqs(fasta=michigan.trim.contigs.good.unique.good.filter.fasta, count=michigan.trim.contigs.good.good.count_table)"
mothur "#chimera.vsearch(fasta=michigan.trim.contigs.good.unique.good.filter.unique.fasta, count=michigan.trim.contigs.good.unique.good.filter.count_table, dereplicate=t, processors=2, abskew=1.9, minh=.3, xn=8, mindiv=.5, mindiffs=3, dn=1.4)"
mothur "#remove.seqs(fasta=michigan.trim.contigs.good.unique.good.filter.unique.fasta, accnos=michigan.trim.contigs.good.unique.good.filter.unique.denovo.vsearch.accnos)"
cp michigan.trim.contigs.good.unique.good.filter.unique.pick.fasta temp.fasta
cp michigan.trim.contigs.good.unique.good.filter.denovo.vsearch.pick.count_table temp.count_table
rm mothur.*.logfile 
rm michigan.*
rm SRR*
rm silva.*
mv temp.fasta michigan.fasta
mv temp.count_table michigan.count_table

printf "ending michigan qc\n" >> timing.txt
date >> timing.txt