#!/bin/bash

# Robin Rohwer

# Batch file to process the mouse gut control reads for the TaxAss Manuscript
# This data is from the mothur miSeq tutorial- aka the "stability" dataset used as an example
# I downloaded the full version of the data from the miSeq SOP links:
# https://www.mothur.org/wiki/MiSeq_SOP   and follow the "full dataset" link  
# More directions in README-TaxAss-BatchFiles

# get ballpark timing estimate
printf "starting mouse gut qc\n" >> timing.txt
date >> timing.txt

# trim reference alignment to primer region (following exactly the SOP coordinates)
cp ../../ReferenceDatabases/silva.seed_v128.align silva.seed_v128.align
mothur "#pcr.seqs(fasta=silva.seed_v128.align, start=11894, end=25319, keepdots=F, nomatch=reject, pdiffs=0, rdiffs=0)" &&

# convert paired fastq into fasta
mothur "#make.file(inputdir=./, type=fastq, prefix=mousegut, numcols=3)" &&
mothur "#make.contigs(file=mousegut.files, processors=2, pdiffs=0, bdiffs=0, tdiffs=0, checkorient=f, align=needleman, match=1, mismatch=-1, gapopen=-2, gapextend=-1, insert=20, deltaq=6, trimoverlap=F, rename=F)" 

# use mothur to QC, align, and chimera-check the fasta file
mothur "#screen.seqs(fasta=mousegut.trim.contigs.fasta, group=mousegut.contigs.groups, maxambig=0, maxlength=275, processors=2)"
mothur "#unique.seqs(fasta=mousegut.trim.contigs.good.fasta)"
mothur "#count.seqs(name=mousegut.trim.contigs.good.names, group=mousegut.contigs.good.groups)"
mothur "#align.seqs(fasta=mousegut.trim.contigs.good.unique.fasta, reference=silva.seed_v128.pcr.align, flip=t, processors=2)"
# start=1968 and end=11550 (following exactly SOP coordinates)
mothur "#screen.seqs(fasta=mousegut.trim.contigs.good.unique.align, count=mousegut.trim.contigs.good.count_table, start=1968, end=11550, maxhomop=8, processors=2)"
mothur "#filter.seqs(fasta=mousegut.trim.contigs.good.unique.good.align, vertical=T, trump=., processors=2)" 
mothur "#unique.seqs(fasta=mousegut.trim.contigs.good.unique.good.filter.fasta, count=mousegut.trim.contigs.good.good.count_table)"
# skip pre.cluster() because not clustering!
mothur "#chimera.vsearch(fasta=mousegut.trim.contigs.good.unique.good.filter.unique.fasta, count=mousegut.trim.contigs.good.unique.good.filter.count_table, dereplicate=t, processors=2, abskew=1.9, minh=.3, xn=8, mindiv=.5, mindiffs=3, dn=1.4)"
mothur "#remove.seqs(fasta=mousegut.trim.contigs.good.unique.good.filter.unique.fasta, accnos=mousegut.trim.contigs.good.unique.good.filter.unique.denovo.vsearch.accnos)"
cp mousegut.trim.contigs.good.unique.good.filter.unique.pick.fasta temp.fasta
cp mousegut.trim.contigs.good.unique.good.filter.denovo.vsearch.pick.count_table temp.count_table
rm mothur.*.logfile 
rm *.fastq
rm mousegut.*
rm silva.*
mv temp.fasta mousegut.fasta
mv temp.count_table mousegut.count_table

printf "ending mousegut qc\n" >> timing.txt
date >> timing.txt