README for ReferenceDatabases folder

Download the reference databases into this folder. For details see the main README directions.