#!/bin/bash

# Robin Rohwer

# Batch file to process the Bog reads (epilimnion and hypolimnion) for the TaxAss Manuscript
# The Bogs are all from the same ERP016854 available via NCBI SRA. I sorted out the Trout Bog
# epilimnion and hypolimnion accession numbers based on the sample names (TBE and TBH, respectively).
# More directions in README-TaxAss-BatchFiles

# get ballpark timing estimate
printf "starting bogs hypo qc\n" >> timing.txt
date >> timing.txt

# trim reference alignment (Pat Schloss's SILVA SEED) to Bog's V4 primer region: forward GTGCCAGCMGCCGCGGTAA reverse GGACTACHVGGGTWTCTAAT
# these coordinates account for a bug in the current version of mother v.1.39.5 trims an extra bp off the forward end
# the ERR bogs sequences already have the primer trimmed off of them
cp ../../ReferenceDatabases/silva.seed_v128.align silva.seed_v128.align
mothur "#pcr.seqs(fasta=silva.seed_v128.align, start=13861, end=23444, keepdots=F, nomatch=reject, pdiffs=0, rdiffs=0)" &&
rm mothur.*.logfile 

# download the fastq files from NCBI SRA, search SRA number ERP016854 in the search bar
# at top right corner of page click send to -> file -> accession list save with default name: SraAccList.txt
while read "SRR"; do
   echo "$SRR"
   fastq-dump --split-files --skip-technical --outdir ./ "$SRR"
done < SraAccList.txt

# use vsearch to QC the single-read illumina fastq data and convert to mothur-friendly fasta (mothur can't handle this old format well)
fastqfiles=`ls *.fastq`
fastqnames=`echo $fastqfiles | sed 's/\.fastq//g'`
fastastring=""
groupstring=""
for SRR in $fastqnames
do
   echo $SRR
   # length (removes 10% reads) and max expected errors (removes another 4% reads) chosen to balance read quality with reads remaining
   vsearch --fastq_filter $SRR.fastq --fastq_trunclen 133 --fastq_maxee .5 --fastaout $SRR.trim.fasta
   fastastring+="-$SRR.trim.fasta"
   groupstring+="-$SRR"
done
mothurfastastring=`echo $fastastring | sed 's/-//'`
mothurgroupstring=`echo $groupstring | sed 's/-//'`
mothur "#merge.files(input=$mothurfastastring, output=bogs.trim.contigs.fasta)" &&
mothur "#make.group(fasta=$mothurfastastring, groups=$mothurgroupstring)" &&
mv *.groups bogs.contigs.groups
rm mothur.*.logfile 

# use mothur to QC, align, and chimera-check the fasta file
mothur "#screen.seqs(fasta=bogs.trim.contigs.fasta, group=bogs.contigs.groups, maxambig=0, maxhomop=9)"
mothur "#unique.seqs(fasta=bogs.trim.contigs.good.fasta)"
mothur "#count.seqs(name=bogs.trim.contigs.good.names, group=bogs.contigs.good.groups)"
mothur "#align.seqs(fasta=bogs.trim.contigs.good.unique.fasta, reference=silva.seed_v128.pcr.align, flip=t)"
# start=1 and end=7469 chosen based on alignment of majority of sequences
mothur "#screen.seqs(fasta=bogs.trim.contigs.good.unique.align, count=bogs.trim.contigs.good.count_table, start=1, end=7469)"
mothur "#filter.seqs(fasta=bogs.trim.contigs.good.unique.good.align, vertical=T, trump=.)" 
mothur "#unique.seqs(fasta=bogs.trim.contigs.good.unique.good.filter.fasta, count=bogs.trim.contigs.good.good.count_table)"
mothur "#chimera.vsearch(fasta=bogs.trim.contigs.good.unique.good.filter.unique.fasta, count=bogs.trim.contigs.good.unique.good.filter.count_table, dereplicate=t, processors=1, abskew=1.9, minh=.3, xn=8, mindiv=.5, mindiffs=3, dn=1.4)"
mothur "#remove.seqs(fasta=bogs.trim.contigs.good.unique.good.filter.unique.fasta, accnos=bogs.trim.contigs.good.unique.good.filter.unique.denovo.vsearch.accnos)"
cp bogs.trim.contigs.good.unique.good.filter.unique.pick.fasta temp.fasta
cp bogs.trim.contigs.good.unique.good.filter.denovo.vsearch.pick.count_table temp.count_table
rm mothur.*.logfile 
rm bogs.*
rm ERR*
rm silva.*
# diff name from epi
mv temp.fasta bog_hypo.fasta
mv temp.count_table bog_hypo.count_table

printf "ending bogs hypo qc\n" >> timing.txt
date >> timing.txt


