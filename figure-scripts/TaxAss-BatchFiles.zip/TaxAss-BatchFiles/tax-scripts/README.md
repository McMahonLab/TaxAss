Scripts for 16S Taxonomy Assignment Workflow
===

This folder contains the scripts used for OTU assignment. Detailed descriptions of them are in the `Clean Workflow.txt` document.